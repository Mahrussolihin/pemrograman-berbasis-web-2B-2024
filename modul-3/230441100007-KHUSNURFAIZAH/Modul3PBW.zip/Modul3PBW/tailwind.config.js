/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./lingkungan2.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

